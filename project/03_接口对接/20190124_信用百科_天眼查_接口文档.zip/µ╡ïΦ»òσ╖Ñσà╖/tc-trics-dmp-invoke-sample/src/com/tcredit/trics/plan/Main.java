package com.tcredit.trics.plan;

import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;

import com.tcredit.trics.utils.sign.SignUtil;
/**
 * 这是java调取三方接口的例子。
 * 假设该接口有三个参数：name,idcard,mobile
 *
 */
public class Main {
	// 三方接口地址
	public static final String url = "http://124.207.122.29:18080/dmp-service-web/service/tcredit/getVerifyMobileInfo3C";
	public static final String appId = "a8e319a8b6f64b3e91024e7792a2c701";
	public static final String tokenId = "5f69b81d04f14dfea669252892a25d0f";

	public static void main(String[] args) throws Exception{

		// 构建入参
    	Map<String,String> param = new HashMap<>();
    	param.put("appId", appId);
    	param.put("name", "韦宏贵");
		param.put("mobile", "18820601856");
		param.put("idcard", "45272819940617271X");

		// 计算签名
        String sign = SignUtil.signature(tokenId, param);
        param.put("sign", sign);

    	// post请求发起环节
        String response = Jsoup.connect(url).ignoreContentType(true).timeout(10000000).data(param).post().text();
    	System.out.println("返回值为:"+response);
	}

}
