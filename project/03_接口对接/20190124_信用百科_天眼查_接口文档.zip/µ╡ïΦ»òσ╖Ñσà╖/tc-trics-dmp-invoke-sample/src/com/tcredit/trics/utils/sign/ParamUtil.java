package com.tcredit.trics.utils.sign;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class ParamUtil {
    /**
     * 格式化参数，按key按字典序排列并以&隔开，生成形如key1=value1&key2=value2...的字符串
     *
     * @param params
     *            参数map
     * @return
     */
    public static String sortMap(Map<String, String> params) {
        if (null == params || params.size() == 0) {
            return ""; // 参数map为空时返回空串
        }

        // 按key排序
        StringBuffer sb = new StringBuffer();
        Map<String, String> sortMap = new TreeMap<String, String>(
                new Comparator<String>() {
                    // 实现比较器
                    public int compare(String str1, String str2) {
                        return str1.compareTo(str2);
                    }
                });
        sortMap.putAll(params);
        for (Map.Entry<String, String> entry : sortMap.entrySet()) {
            if (entry.getKey()!= null && entry.getKey().trim().length()!= 0
                    && entry.getValue()!= null && entry.getValue().trim().length()!= 0) {
                sb.append("&").append(entry.getKey()).append("=")
                        .append(entry.getValue());
            }
        }

        // 返回结果字符串
        if (sb.length() > 1) {
            return sb.substring(1);
        } else {
            return "";
        }
    }

    /**
     * 转换参数map
     *
     * @param map
     * @return
     */
    public static Map<String, String> convertMap(Map<String, String[]> map) {
        Map<String, String> params = new HashMap<String, String>();
        if (map != null && map.size() > 0) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String[]> entity : map.entrySet()) {
                String key = entity.getKey();
                String[] arr = entity.getValue();
                String value = "";
                if (arr != null && arr.length > 0) {
                    sb.delete(0, sb.length());
                    // 将字符串数组转为字符串，中间以逗号隔开
                    for (String item : arr) {
                        sb.append(",").append(item);
                    }
                    if (sb.length() > 0) {
                        value = sb.substring(1);
                        params.put(key, value);
                    }
                }
            }
        }
        return params;
    }
}